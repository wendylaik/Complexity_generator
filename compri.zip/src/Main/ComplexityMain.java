
package Main;

import Classes.Read_File;

/**
 *
 * @author franc
 */
public class ComplexityMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Read_File re = new Read_File();
        re.read("ejemplo.java");
    }
    
}
